package Controlador;

import Modelo.IStoredProcedure;
import java.sql.SQLException;

// Clase Decoradora para la funcionalidad adicional de InsertarExcedenteProcedure
public class DecoratorControlador implements IStoredProcedure {
    private IStoredProcedure insertarExcedenteProcedure;
    private double cantidad;

    public DecoratorControlador(IStoredProcedure insertarExcedenteProcedure, double cantidad) {
        this.insertarExcedenteProcedure = insertarExcedenteProcedure;
        this.cantidad = cantidad;
    }

    @Override
    public void ejecutar() throws SQLException {
        // Validación adicional antes de ejecutar el procedimiento
        if (cantidad <= 0) {
            System.out.println("Error: La cantidad de excedente debe ser mayor que 0.");
            return;
        }

        // Llamar al procedimiento original
        insertarExcedenteProcedure.ejecutar();
        
        // Funcionalidad adicional después de ejecutar
        System.out.println("Excedente insertado correctamente con cantidad: " + cantidad);
    }
}
