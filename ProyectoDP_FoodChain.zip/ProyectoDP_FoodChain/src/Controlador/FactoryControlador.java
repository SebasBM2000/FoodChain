package Controlador;

import Modelo.IStoredProcedure;
import Modelo.InsertarDonacionProcedure;
import Modelo.InsertarExcedenteProcedure;
import Modelo.InsertarRecompensaProcedure;
import Modelo.InsertarTransporteProcedure;
import Modelo.InsertarUsuarioProcedure;
import Modelo.ObtenerDonacionesPorEstadoProcedure;
import Modelo.ObtenerExcedentesPorEstadoProcedure;
import Modelo.ObtenerRangosPorTipoDeRecompensaProcedure;
import Modelo.ObtenerRecompensasPorUsuarioProcedure;
import Modelo.ObtenerTransportePorEstadoProcedure;

// Factory para crear instancias de los procedimientos almacenados
public class FactoryControlador {

    public IStoredProcedure crearProcedimiento(String tipo, Object... params) {
        switch (tipo) {
            
            case "InsertarUsuario":
                return new InsertarUsuarioProcedure(
                    (String) params[0], 
                    (String) params[1], 
                    (String) params[2], 
                    (String) params[3], 
                    (String) params[4]  
                );
                
            case "InsertarExcedente":
                return new InsertarExcedenteProcedure(
                    (int) params[0],    
                    (String) params[1], 
                    (double) params[2], 
                    (String) params[3], 
                    (String) params[4], 
                    (String) params[5], 
                    (String) params[6]  
                );
                
            case "ObtenerExcedentesPorEstado":
                return new ObtenerExcedentesPorEstadoProcedure(
                    (String) params[0]  
                );
                
            case "InsertarDonacion":
                return new InsertarDonacionProcedure(
                    (Integer) params[0], 
                    (Integer) params[1], 
                    (String) params[2], 
                    (String) params[3], 
                    (String) params[4]
            );
            
            case "ObtenerDonacionesPorEstado":
                return new ObtenerDonacionesPorEstadoProcedure(
                    (String) params[0]
                );
    
            case "InsertarRecompensa":
                return new InsertarRecompensaProcedure(
                    (Integer) params[0], 
                    (Integer) params[1],
                    (Integer) params[2], 
                    (String) params[3]
            );

            case "ObtenerRecompensasPorUsuario":
                return new ObtenerRecompensasPorUsuarioProcedure(
                    (Integer) params[0]
                );
                
            case "ObtenerRangosPorTipoDeRecompensa":
                return new ObtenerRangosPorTipoDeRecompensaProcedure(
                    (String) params[0]
                );

            case "InsertarTransporte":
                return new InsertarTransporteProcedure(
                    (Integer) params[0], 
                    (String) params[1], 
                    (String) params[2], 
                    (String) params[3], 
                    (String) params[4], 
                    (String) params[5]
            );
    
            case "ObtenerTransportePorEstado":
                return new ObtenerTransportePorEstadoProcedure(
                    (String) params[0]);
    
            default:
                throw new IllegalArgumentException("Tipo de procedimiento no reconocido: " + tipo);
        }
    }
}