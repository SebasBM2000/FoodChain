package Controlador;

import java.sql.SQLException;
import Modelo.IStoredProcedure;

// Facade para la creación y ejecución de procedimientos almacenados
public class FacadeControlador {
    
    private FactoryControlador factory;

    public FacadeControlador() {
        this.factory = new FactoryControlador();
    }
    
    public void insertarUsuario(String nombre, String tipoUsuario, String email, String telefono, String direccion) {
        try {
            IStoredProcedure procedure = factory.crearProcedimiento("InsertarUsuario", nombre, tipoUsuario, email, telefono, direccion);
            procedure.ejecutar();
        } catch (SQLException e) {
            System.err.println("Error al ejecutar el procedimiento InsertarUsuario: " + e.getMessage());
        }
    }

    public void insertarExcedente(int usuarioID, String descripcion, double cantidad, String unidadMedida, String fechaCreacion, String fechaCaducidad, String estado) {
        try {
            IStoredProcedure procedure = factory.crearProcedimiento("InsertarExcedente", usuarioID, descripcion, cantidad, unidadMedida, fechaCreacion, fechaCaducidad, estado);
            
            // Aquí aplicamos el decorador con la validación de la cantidad
            procedure = new DecoratorControlador(procedure, cantidad);

            procedure.ejecutar();  // Ejecutar con el decorador
        } catch (SQLException e) {
            System.err.println("Error al ejecutar el procedimiento InsertarExcedente: " + e.getMessage());
        }
    }

    public void obtenerExcedentesPorEstado(String estado) {
        try {
            IStoredProcedure procedure = factory.crearProcedimiento("ObtenerExcedentesPorEstado", estado);
            procedure.ejecutar();
        } catch (SQLException e) {
            System.err.println("Error al ejecutar el procedimiento ObtenerExcedentesPorEstado: " + e.getMessage());
        }
    }

    public void insertarDonacion(int excedenteID, int organizacionID, String fechaAsignacion, String fechaRecoleccion, String estado) {
        try {
            IStoredProcedure procedure = factory.crearProcedimiento("InsertarDonacion", excedenteID, organizacionID, fechaAsignacion, fechaRecoleccion, estado);
            procedure.ejecutar();
        } catch (SQLException e) {
            System.err.println("Error al ejecutar el procedimiento InsertarDonacion: " + e.getMessage());
        }
    }

    public void obtenerDonacionesPorEstado(String estado) {
        try {
            IStoredProcedure procedure = factory.crearProcedimiento("ObtenerDonacionesPorEstado", estado);
            procedure.ejecutar();
        } catch (SQLException e) {
            System.err.println("Error al ejecutar el procedimiento ObtenerDonacionesPorEstado: " + e.getMessage());
        }
    }
    
    public void insertarRecompensa(int donacionID, int usuarioID, int puntos, String fechaOtorgacion) {
        try {
            IStoredProcedure procedure = factory.crearProcedimiento("InsertarRecompensa", donacionID, usuarioID, puntos, fechaOtorgacion);
            procedure.ejecutar();
        } catch (SQLException e) {
            System.err.println("Error al ejecutar el procedimiento InsertarRecompensa: " + e.getMessage());
        }
    }

    public void obtenerRecompensasPorUsuario(int usuarioID) {
        try {
            IStoredProcedure procedure = factory.crearProcedimiento("ObtenerRecompensasPorUsuario", usuarioID);
            procedure.ejecutar();
        } catch (SQLException e) {
            System.err.println("Error al ejecutar el procedimiento ObtenerRecompensasPorUsuario: " + e.getMessage());
        }
    }
    
    public void ObtenerRangosPorTipoDeRecompensa(String tipoRecompensa) {
        try {
            IStoredProcedure procedure = factory.crearProcedimiento("ObtenerRangosPorTipoDeRecompensa", tipoRecompensa);
            procedure.ejecutar();
        } catch (SQLException e) {
            System.err.println("Error al ejecutar el procedimiento ObtenerRangosPorTipoDeRecompensa: " + e.getMessage());
        }
    }    
    
    public void insertarTransporte(int donacionID, String vehiculo, String conductor, String fechaInicio, String fechaFin, String estado) {
        try {
            IStoredProcedure procedure = factory.crearProcedimiento("InsertarTransporte", donacionID, vehiculo, conductor, fechaInicio, fechaFin, estado);
            procedure.ejecutar();
        } catch (SQLException e) {
            System.err.println("Error al ejecutar el procedimiento InsertarTransporte: " + e.getMessage());
        }
    }

    public void obtenerTransportePorEstado(String estado) {
        try {
            IStoredProcedure procedure = factory.crearProcedimiento("ObtenerTransportePorEstado", estado);
            procedure.ejecutar();
        } catch (SQLException e) {
            System.err.println("Error al ejecutar el procedimiento ObtenerTransportePorEstado: " + e.getMessage());
        }
    }
}