package Vista;

import Controlador.FacadeControlador;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public interface InterfaceObserver {
    void update(String submodulo, JTextField textFieldNumero, JComboBox<String> comboBoxOpcionesAjuste, FacadeControlador facadecontrolador, DefaultTableModel tableModel);
}
