package Vista;

import java.util.Stack;
import javax.swing.JButton;

public class CaretakerMemento {
    private  Stack<MementoVista> memento = new Stack<>();
    
    public void save(OriginatorMemento originator){
        memento.push(originator.save());
    }
    
    public void undo(OriginatorMemento originator, JButton submoduloBtn){
       if(!memento.isEmpty()){
           originator.restore(memento.pop(), submoduloBtn);
       } 
    }
}
