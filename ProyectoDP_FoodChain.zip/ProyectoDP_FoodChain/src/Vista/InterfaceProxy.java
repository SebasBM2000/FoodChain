package Vista;

import Controlador.FacadeControlador;

public interface InterfaceProxy {
    public void agregarDatosProxy(String submoduloActual, FacadeControlador facadecontrolador);
}
