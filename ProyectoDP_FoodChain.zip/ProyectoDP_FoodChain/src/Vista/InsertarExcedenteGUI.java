package Vista;

import Controlador.FacadeControlador;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class InsertarExcedenteGUI extends JPanel {
    
    private JTextField idLocalField;
    private JTextField descripcionExcedenteField;
    private JTextField cantidadExcedenteField;
    private JTextField unidadMedidaField;
    private JTextField fechaElaboracionField;
    private JTextField fechaCaducidadField;
    private JComboBox<String> estadoExcedenteCombo;    
    
    public InsertarExcedenteGUI() {
        this.idLocalField = new JTextField(20);
        this.descripcionExcedenteField = new JTextField(20);
        this.cantidadExcedenteField = new JTextField(20);
        this.unidadMedidaField = new JTextField(20);
        this.fechaElaboracionField = new JTextField(20);
        this.fechaCaducidadField = new JTextField(20);
        this.estadoExcedenteCombo = new JComboBox<>(new String[]{"Disponible", "Asignado", "Entregado"});
    }
    
    protected void insertarDatosExcedente(FacadeControlador facadecontrolador){
        if (idLocalField.getText().isEmpty() || descripcionExcedenteField.getText().isEmpty() ||
                cantidadExcedenteField.getText().isEmpty() || unidadMedidaField.getText().isEmpty() ||
                fechaElaboracionField.getText().isEmpty() || fechaCaducidadField.getText().isEmpty()) {
            
            JOptionPane.showMessageDialog(this, "No se pudo agregar a la base de datos, por favor complete el cuadro de detalles.");
            return;
        }
        
        try {
            facadecontrolador.insertarExcedente(
                    Integer.parseInt(idLocalField.getText()),
                    descripcionExcedenteField.getText(),
                    Double.parseDouble(cantidadExcedenteField.getText()),
                    unidadMedidaField.getText(),
                    fechaElaboracionField.getText(),
                    fechaCaducidadField.getText(),
                    String.valueOf(estadoExcedenteCombo.getSelectedItem())
            );
            
            JOptionPane.showMessageDialog(this, "Agregando los datos a la tabla Excedentes...");
        
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al agregar a la base de datos: " + e.getMessage());
        }
    }
    
    protected void eliminarDatosExcedente(){
        idLocalField.setText("");
        descripcionExcedenteField.setText("");
        cantidadExcedenteField.setText("");
        unidadMedidaField.setText("");
        fechaElaboracionField.setText("");
        fechaCaducidadField.setText("");
        estadoExcedenteCombo.setSelectedIndex(0);        
    }

    public JTextField getIdLocalField() {
        return this.idLocalField;
    }

    public JTextField getDescripcionExcedenteField() {
        return this.descripcionExcedenteField;
    }

    public JTextField getCantidadExcedenteField() {
        return this.cantidadExcedenteField;
    }

    public JTextField getUnidadMedidaField() {
        return this.unidadMedidaField;
    }

    public JTextField getFechaElaboracionField() {
        return this.fechaElaboracionField;
    }

    public JTextField getFechaCaducidadField() {
        return this.fechaCaducidadField;
    }

    public JComboBox<String> getEstadoExcedenteCombo() {
        return this.estadoExcedenteCombo;
    }
}
