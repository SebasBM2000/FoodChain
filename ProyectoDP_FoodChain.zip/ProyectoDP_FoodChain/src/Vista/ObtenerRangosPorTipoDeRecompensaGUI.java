package Vista;

import Controlador.FacadeControlador;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

public class ObtenerRangosPorTipoDeRecompensaGUI extends JPanel {
    
    // Método para actualizar la tabla según la opción seleccionada
    protected void actualizarTablaRangos(JComboBox<String> comboBoxOpcionesAjuste, FacadeControlador facadecontrolador, DefaultTableModel tableModel) {
        tableModel.setRowCount(0); // Limpiar la tabla
        try {
            // Obtener la opción seleccionada del desplegable
            String opcionSeleccionada = (String) comboBoxOpcionesAjuste.getSelectedItem();

            // Mostrar tabla con los 2 tipos de recompensas
            if ("Mostrar tabla con los 2 tipos de recompensas".equals(opcionSeleccionada)) {
                obtenerDatosDesdeConsolaRangos("Física", facadecontrolador, tableModel);
                obtenerDatosDesdeConsolaRangos("No Física", facadecontrolador, tableModel);

            }
            // Mostrar tabla con tipo de recompensa 'Física'
            else if ("Mostrar tabla con tipo de recompensa 'Física'".equals(opcionSeleccionada)) {
                obtenerDatosDesdeConsolaRangos("Física", facadecontrolador, tableModel);
            }
            // Mostrar tabla con tipo de recompensa 'No Física'
            else if ("Mostrar tabla con tipo de recompensa 'No Física'".equals(opcionSeleccionada)) {
                obtenerDatosDesdeConsolaRangos("No Física", facadecontrolador, tableModel);
            }
            
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error al actualizar la tabla: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // Método para obtener datos desde la consola según el tipo de recompensa seleccionado
    protected void obtenerDatosDesdeConsolaRangos(String tipoRecompensa, FacadeControlador facadecontrolador, DefaultTableModel tableModel) {
        // Redirigir la salida de consola a un Stream
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream originalOut = System.out;
        PrintStream printStream = new PrintStream(baos);
        System.setOut(printStream);

        // Llamar al controlador para ejecutar el procedimiento para un estado específico
        facadecontrolador.ObtenerRangosPorTipoDeRecompensa(tipoRecompensa);

        // Restaurar la salida de consola
        System.setOut(originalOut);

        // Procesar la salida capturada
        String[] filas = baos.toString().split("\n");
        Object[] filaActual = new Object[5];
        int index = 0;

        for (String linea : filas) {
            String[] partes = linea.split(": ");
            if (partes.length > 1) {
                filaActual[index] = partes[1];
                index++;
                if (index == 5) {
                    tableModel.addRow(filaActual);
                    filaActual = new Object[5];
                    index = 0;
                }
            }
        }
    }   
}
