package Vista;

import Controlador.FacadeControlador;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

public class ObtenerDonacionesPorEstadoGUI extends JPanel {
    
    // Método para actualizar la tabla según la opción seleccionada
    protected void actualizarTablaDonaciones(JComboBox<String> comboBoxOpcionesAjuste, FacadeControlador facadecontrolador, DefaultTableModel tableModel) {
        tableModel.setRowCount(0); // Limpiar la tabla
        
        try {
            // Obtener la opción seleccionada del desplegable
            String opcionSeleccionada = (String) comboBoxOpcionesAjuste.getSelectedItem();

            // Mostrar tabla con los 2 estados
            if ("Mostrar tabla con los 2 estados".equals(opcionSeleccionada)) {
                obtenerDatosDesdeConsolaDonaciones("Asignado", facadecontrolador, tableModel);
                obtenerDatosDesdeConsolaDonaciones("Recolectado", facadecontrolador, tableModel);
            }
            // Mostrar tabla con estado 'Asignado'
            else if ("Mostrar tabla con estado 'Asignado'".equals(opcionSeleccionada)) {
                obtenerDatosDesdeConsolaDonaciones("Asignado", facadecontrolador, tableModel);
            }
            // Mostrar tabla con estado 'Recolectado'
            else if ("Mostrar tabla con estado 'Recolectado'".equals(opcionSeleccionada)) {
                obtenerDatosDesdeConsolaDonaciones("Recolectado", facadecontrolador, tableModel);
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error al actualizar la tabla: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Método para obtener datos desde la consola según el estado seleccionado
    protected void obtenerDatosDesdeConsolaDonaciones(String estado, FacadeControlador facadecontrolador, DefaultTableModel tableModel) {
        // Redirigir la salida de consola a un Stream
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream originalOut = System.out;
        PrintStream printStream = new PrintStream(baos);
        System.setOut(printStream);

        // Llamar al controlador para ejecutar el procedimiento para un estado específico
        facadecontrolador.obtenerDonacionesPorEstado(estado);

        // Restaurar la salida de consola
        System.setOut(originalOut);

        // Procesar la salida capturada
        String[] filas = baos.toString().split("\n");
        Object[] filaActual = new Object[6];
        int index = 0;

        for (String linea : filas) {
            String[] partes = linea.split(": ");
            if (partes.length > 1) {
                filaActual[index] = partes[1];
                index++;
                if (index == 6) {
                    tableModel.addRow(filaActual);
                    filaActual = new Object[6];
                    index = 0;
                }
            }
        }
    }
}