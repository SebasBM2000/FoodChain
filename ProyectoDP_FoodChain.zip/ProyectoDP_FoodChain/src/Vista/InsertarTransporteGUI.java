package Vista;

import Controlador.FacadeControlador;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class InsertarTransporteGUI extends JPanel {
    
    private JTextField idDonacionField;
    private JTextField descripcionVehiculoField;
    private JTextField nombreConductorField;
    private JTextField fechaSalidaVehiculoField;
    private JTextField fechaEntregaVehiculoField;
    private JComboBox<String> estadoTransporteCombo;
    
    public InsertarTransporteGUI(){
        this.idDonacionField = new JTextField(20);
        this.descripcionVehiculoField = new JTextField(20);
        this.nombreConductorField = new JTextField(20);
        this.fechaSalidaVehiculoField = new JTextField(20);
        this.fechaEntregaVehiculoField = new JTextField(20);
        this.estadoTransporteCombo = new JComboBox<>(new String[]{"Planificado", "En progreso", "Completado"});        
    }   
    
    protected void insertarDatosTransporte(FacadeControlador facadecontrolador){
        if (idDonacionField.getText().isEmpty() || descripcionVehiculoField.getText().isEmpty() ||
                nombreConductorField.getText().isEmpty() || fechaSalidaVehiculoField.getText().isEmpty() ||
                fechaEntregaVehiculoField.getText().isEmpty()) {
            
            JOptionPane.showMessageDialog(this, "No se pudo agregar a la base de datos, por favor complete el cuadro de detalles.");
            return;
        }
        
        try {
            facadecontrolador.insertarTransporte(
                    Integer.parseInt(idDonacionField.getText()),
                    descripcionVehiculoField.getText(),
                    nombreConductorField.getText(),
                    fechaSalidaVehiculoField.getText(),
                    fechaEntregaVehiculoField.getText(),
                    String.valueOf(estadoTransporteCombo.getSelectedItem())
            );
            
            JOptionPane.showMessageDialog(this, "Agregando los datos a la tabla Transporte...");
        
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al agregar a la base de datos: " + e.getMessage());
        }
    }
    
    protected void eliminarDatosTransporte(){
        idDonacionField.setText("");
        descripcionVehiculoField.setText("");
        nombreConductorField.setText("");
        fechaSalidaVehiculoField.setText("");
        fechaEntregaVehiculoField.setText("");
        estadoTransporteCombo.setSelectedIndex(0);        
    }
    
    public JTextField getIdDonacionField() {
        return this.idDonacionField;
    }

    public JTextField getDescripcionVehiculoField() {
        return this.descripcionVehiculoField;
    }

    public JTextField getNombreConductorField() {
        return this.nombreConductorField;
    }

    public JTextField getFechaSalidaVehiculoField() {
        return this.fechaSalidaVehiculoField;
    }

    public JTextField getFechaEntregaVehiculoField() {
        return this.fechaEntregaVehiculoField;
    }

    public JComboBox<String> getEstadoTransporteCombo() {
        return this.estadoTransporteCombo;
    }    
}
