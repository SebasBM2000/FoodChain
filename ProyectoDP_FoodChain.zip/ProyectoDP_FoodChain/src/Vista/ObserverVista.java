package Vista;

import javax.swing.JComboBox;
import Controlador.FacadeControlador;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class ObserverVista implements InterfaceObserver {
    
    String nombreTabla;
    ObtenerDonacionesPorEstadoGUI obtenerdonacionesporestadoGUI;
    ObtenerExcedentesPorEstadoGUI obtenerexcedentesporestadoGUI;
    ObtenerRangosPorTipoDeRecompensaGUI obtenerrangosportipoderecompensaGUI;
    ObtenerRecompensasPorUsuarioGUI obtenerrecompensasporusuarioGUI;
    ObtenerTransportePorEstadoGUI obtenertransporteporestadoGUI;
    
    public ObserverVista(String nombreTabla){
        this.nombreTabla = nombreTabla;
        this.obtenerdonacionesporestadoGUI = new ObtenerDonacionesPorEstadoGUI();
        this.obtenerexcedentesporestadoGUI = new ObtenerExcedentesPorEstadoGUI();
        this.obtenerrangosportipoderecompensaGUI = new ObtenerRangosPorTipoDeRecompensaGUI();
        this.obtenerrecompensasporusuarioGUI = new ObtenerRecompensasPorUsuarioGUI();
        this.obtenertransporteporestadoGUI = new ObtenerTransportePorEstadoGUI();
    }

    public void actualizarTablasObserver(String submodulo, JTextField textFieldNumero, JComboBox<String> comboBoxOpcionesAjuste, FacadeControlador facadecontrolador, DefaultTableModel tableModel){
        if (submodulo.equals("Obtener excedentes por estado")){
            obtenerexcedentesporestadoGUI.actualizarTablaExcedentes(comboBoxOpcionesAjuste, facadecontrolador, tableModel);           
        }
        if (submodulo.equals("Obtener donaciones por estado")){
            obtenerdonacionesporestadoGUI.actualizarTablaDonaciones(comboBoxOpcionesAjuste, facadecontrolador, tableModel);
        }
        if (submodulo.equals("Obtener recompensas por usuario")){
            obtenerrecompensasporusuarioGUI.actualizarTablaRecompensas(textFieldNumero, facadecontrolador, tableModel);
        }
        if (submodulo.equals("Obtener rangos por tipo de recompensa")){
            obtenerrangosportipoderecompensaGUI.actualizarTablaRangos(comboBoxOpcionesAjuste, facadecontrolador, tableModel);
        }
        if (submodulo.equals("Obtener transporte por estado")){
            obtenertransporteporestadoGUI.actualizarTablaTransportes(comboBoxOpcionesAjuste, facadecontrolador, tableModel);
        }
    }

    @Override
    public void update(String submodulo, JTextField textFieldNumero, JComboBox<String> comboBoxOpcionesAjuste, FacadeControlador facadecontrolador, DefaultTableModel tableModel) {
        actualizarTablasObserver(submodulo, textFieldNumero, comboBoxOpcionesAjuste, facadecontrolador, tableModel);
        if (submodulo.equals("Obtener excedentes por estado") || submodulo.equals("Obtener donaciones por estado") || submodulo.equals("Obtener rangos por tipo de recompensa") || submodulo.equals("Obtener transporte por estado")){
            JOptionPane.showMessageDialog(null, "Se ha actualizado correctamente la tabla " + nombreTabla + " en el cuadro de detalles");
        }
    }
}
