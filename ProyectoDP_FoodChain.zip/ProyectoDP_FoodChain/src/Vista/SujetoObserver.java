package Vista;

import Controlador.FacadeControlador;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class SujetoObserver {
    
    private List<InterfaceObserver> sujetos = new ArrayList<>();
     
    public void añadir(InterfaceObserver observer){
        sujetos.add(observer);
    }
    
    public void eliminar (InterfaceObserver observer){
        sujetos.remove(observer);
    }
    
    public void actualizar(String submodulo, JTextField textFieldNumero, JComboBox<String> comboBoxOpcionesAjuste, FacadeControlador facadecontrolador, DefaultTableModel tableModel){
        for (InterfaceObserver sujeto : sujetos){
            sujeto.update(submodulo, textFieldNumero, comboBoxOpcionesAjuste, facadecontrolador, tableModel);
        }
    }
}