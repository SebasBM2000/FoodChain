package Vista;

import Controlador.FacadeControlador;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

public class ObtenerExcedentesPorEstadoGUI extends JPanel {
    
    // Método para actualizar la tabla según la opción seleccionada
    protected void actualizarTablaExcedentes(JComboBox<String> comboBoxOpcionesAjuste, FacadeControlador facadecontrolador, DefaultTableModel tableModel) {
        tableModel.setRowCount(0); // Limpiar la tabla
        
        try {
            // Obtener la opción seleccionada del desplegable
            String opcionSeleccionada = (String) comboBoxOpcionesAjuste.getSelectedItem(); 
            
            // Mostrar tabla con los 3 estados
            if ("Mostrar tabla con los 3 estados".equals(opcionSeleccionada)) {
                obtenerDatosDesdeConsolaExcedentes("Asignado", facadecontrolador, tableModel);
                obtenerDatosDesdeConsolaExcedentes("Disponible", facadecontrolador, tableModel);
                obtenerDatosDesdeConsolaExcedentes("Entregado", facadecontrolador, tableModel);
            }
            // Mostrar tabla con estado 'Asignado'
            else if ("Mostrar tabla con estado 'Asignado'".equals(opcionSeleccionada)) {
                obtenerDatosDesdeConsolaExcedentes("Asignado", facadecontrolador, tableModel);
            }
            // Mostrar tabla con estado 'Disponible'
            else if ("Mostrar tabla con estado 'Disponible'".equals(opcionSeleccionada)) {
                obtenerDatosDesdeConsolaExcedentes("Disponible", facadecontrolador, tableModel);
            }
            // Mostrar tabla con estado 'Entregado'
            else if ("Mostrar tabla con estado 'Entregado'".equals(opcionSeleccionada)) {
                obtenerDatosDesdeConsolaExcedentes("Entregado", facadecontrolador, tableModel);                
            }
            
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error al actualizar la tabla: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }    
    
    // Método para obtener datos desde la consola según el estado seleccionado
    protected void obtenerDatosDesdeConsolaExcedentes(String estado, FacadeControlador facadecontrolador, DefaultTableModel tableModel) {
        // Redirigir la salida de consola a un Stream
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream originalOut = System.out;
        PrintStream printStream = new PrintStream(baos);
        System.setOut(printStream);
        facadecontrolador = new FacadeControlador(); // Instancia del controlador
        
        // Llamar al controlador para ejecutar el procedimiento para un estado específico
        facadecontrolador.obtenerExcedentesPorEstado(estado);

        // Restaurar la salida de consola
        System.setOut(originalOut);

        // Procesar la salida capturada
        String[] filas = baos.toString().split("\n");
        Object[] filaActual = new Object[8];
        int index = 0;

        for (String linea : filas) {
            String[] partes = linea.split(": ");
            if (partes.length > 1) {
                filaActual[index] = partes[1];
                index++;
                if (index == 8) {
                    tableModel.addRow(filaActual);
                    filaActual = new Object[8];
                    index = 0;
                }
            }
        }
    }
}