package Vista;

import java.awt.Color;
import javax.swing.JButton;
import javax.swing.UIManager;

public class OriginatorMemento {
    JButton submoduloBtn;
    private String coloractual;
    private String colorguardado;
    
    public void setColor(String coloractual) {
        this.coloractual = coloractual;
    }

    public MementoVista save() {
        colorguardado = coloractual;
        return new MementoVista(colorguardado);
    }

    public MementoVista restore(MementoVista memento, JButton submoduloBtn) {
        colorguardado = memento.getEliminarColor();
        return new MementoVista(colorguardado);        
    }

    public Color getColorActual() {       
        if(colorguardado.equals("Verde Limón")){
            return new Color(204, 255, 0);
        }        
        if(colorguardado.equals("Naranja Claro")){
            return new Color(255, 165, 0);
        }        
        return new Color(204, 225, 255);
    }
}