package Vista;

import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import Controlador.FacadeControlador;
import javax.swing.table.DefaultTableModel;

public class VentanaGUI extends JFrame {
    
    private JPanel cuadroDetalles;    
    private JPanel panelModulos;
    private JPanel panelSubmodulos;
    private JButton agregarBtn;
    private JButton limpiarBtn;
    private JButton buttonActualizar;
    private String submoduloActual;
    private ProxyVista proxyvista;
    private ObserverVista observervista;
    private SujetoObserver sujetoobserver;
    private OriginatorMemento originatormemento;
    private CaretakerMemento caretakermemento;
    private JComboBox<String> comboBoxOpcionesAjuste;
    private DefaultTableModel tableModel;
    private JTable tableExcedentes;
    private JTable tableDonaciones;
    private JTable tableRecompensas;
    private JTable tableRangos;
    private JTable tableTransportes;
    private JTextField textFieldNumero;
    private JScrollPane scrollPane;
    
    public VentanaGUI(){
        proxyvista = new ProxyVista();
        sujetoobserver = new SujetoObserver();
        originatormemento = new OriginatorMemento();
        caretakermemento = new CaretakerMemento();
        
        setTitle("Página de la interfaz de FoodChain");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null);
        setVisible(true);
                     
        // Título central dentro de la interfaz
        JPanel tituloPanelCentral = new JPanel();
        JLabel tituloCentral = new JLabel("FOODCHAIN: REDUCCIÓN DEL DESPERDICIO DE ALIMENTOS Y DISTRIBUCIÓN SOLIDARIA", JLabel.CENTER);
        tituloCentral.setFont(new Font("Arial", Font.BOLD, 14));
        tituloPanelCentral.add(tituloCentral);
        add(tituloPanelCentral, BorderLayout.PAGE_START);

        // Panel principal para organizar módulos, submódulos y cuadro de detalles
        JPanel panelCentral = new JPanel(new BorderLayout());
        add(panelCentral, BorderLayout.CENTER);

        // Panel de módulos en la parte superior del cuadro de detalles
        panelModulos = new JPanel();
        panelModulos.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 5));
        panelModulos.setBorder(BorderFactory.createTitledBorder("Módulos"));
        panelCentral.add(panelModulos, BorderLayout.NORTH);

        // Panel de submodulos (a la izquierda del cuadro de detalles)
        panelSubmodulos = new JPanel();
        panelSubmodulos.setLayout(new GridLayout(0, 1, 5, 5));
        panelSubmodulos.setBorder(BorderFactory.createTitledBorder("Submódulos"));
        panelCentral.add(panelSubmodulos, BorderLayout.WEST);

        // Panel central de detalles con tamaño fijo, ahora como JPanel para agregar campos
        cuadroDetalles = new JPanel();
        cuadroDetalles.setLayout(new GridLayout(7, 2, 5, 5));
        cuadroDetalles.setBorder(BorderFactory.createTitledBorder("Cuadro de detalles"));
        panelCentral.add(new JScrollPane(cuadroDetalles), BorderLayout.CENTER);
      
        // Panel de botones (para agregar y limpiar, solo visible en módulo "Insertar datos")
        JPanel panelBotones = new JPanel();
        agregarBtn = new JButton("AGREGAR A LA BASE DE DATOS");
        limpiarBtn = new JButton("LIMPIAR CUADRO");
        panelBotones.add(agregarBtn);
        panelBotones.add(limpiarBtn);
        agregarBtn.setVisible(false);
        limpiarBtn.setVisible(false);
        add(panelBotones, BorderLayout.SOUTH);      
        
        // Inicializar módulos y submódulos
        inicializarModulos(); 
             
        // Añadir funcionalidad a los botones de agregar y limpiar
        agregarBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                agregarDatos();
            }
        });  
        
        limpiarBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                limpiarCampos();
            }
        }); 
    }
    
    private void inicializarModulos() {
        String[] modulos = {"Insertar datos", "Obtener datos"};
        for (String modulo : modulos) {
            JButton moduloBtn = new JButton(modulo);
            moduloBtn.addActionListener(new ModuloSeleccionadoListener(modulo));
            panelModulos.add(moduloBtn);
        }
    }
    
    private class ModuloSeleccionadoListener implements ActionListener {
        private String modulo;

        public ModuloSeleccionadoListener(String modulo) {
            this.modulo = modulo;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            mostrarSubmodulos(modulo);
            if (modulo.equals("Insertar datos")) {
                agregarBtn.setVisible(true);
                limpiarBtn.setVisible(true);     
            } else {
                agregarBtn.setVisible(false);
                limpiarBtn.setVisible(false);   
            }

        }
    }

    private void mostrarSubmodulos(String modulo) {
        panelSubmodulos.removeAll();

        String[] submodulos;
        if (modulo.equals("Insertar datos")) {
            submodulos = new String[]{"Insertar usuario", "Insertar excedente", "Insertar donación", "Insertar transporte", "Insertar recompensa"};
        } else {
            submodulos = new String[]{"Obtener excedentes por estado", "Obtener donaciones por estado", 
                "Obtener recompensas por usuario", "Obtener rangos por tipo de recompensa", "Obtener transporte por estado"};
        }

        Dimension buttonSize = new Dimension(180, 30);
        for (String submodulo : submodulos) {
            JButton submoduloBtn = new JButton("<html><center>" + submodulo + "</center></html>");
            submoduloBtn.setPreferredSize(buttonSize);
            submoduloBtn.setBackground(new Color(204, 225, 255));
            submoduloBtn.addActionListener(new SubmoduloSeleccionadoListener(submodulo, modulo, submoduloBtn));        
            panelSubmodulos.add(submoduloBtn);           
        }
        
        panelSubmodulos.revalidate();
        panelSubmodulos.repaint();
    }
    
    private class SubmoduloSeleccionadoListener implements ActionListener {
        private String submodulo;
        private String modulo;
        private JButton submoduloBtn;

        public SubmoduloSeleccionadoListener(String submodulo, String modulo, JButton submoduloBtn) {
            this.submodulo = submodulo;
            this.modulo = modulo;
            this.submoduloBtn = submoduloBtn;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            submoduloActual = submodulo;            
            actualizarCuadroDetalles(submodulo, modulo, submoduloBtn);
        }
    }
    
    private void ColorearBoton (String submodulo, JButton submoduloBtn) {
        if (submodulo.equals("Insertar usuario") || submodulo.equals("Insertar excedente") || submodulo.equals("Insertar donación") || submodulo.equals("Insertar transporte") || submodulo.equals("Insertar recompensa")) { 
            originatormemento.setColor("Verde Limón");
            caretakermemento.save(originatormemento);
            submoduloBtn.setBackground(originatormemento.getColorActual());   
            caretakermemento.undo(originatormemento, submoduloBtn);           
        }        
        if (submodulo.equals("Obtener datos") || submodulo.equals("Obtener excedentes por estado") || submodulo.equals("Obtener donaciones por estado") || submodulo.equals("Obtener recompensas por usuario") || submodulo.equals("Obtener rangos por tipo de recompensa") || submodulo.equals("Obtener transporte por estado")){
            originatormemento.setColor("Naranja Claro");
            caretakermemento.save(originatormemento);
            submoduloBtn.setBackground(originatormemento.getColorActual());   
            caretakermemento.undo(originatormemento, submoduloBtn);            
        }           
    }
   
    private void actualizarCuadroDetalles(String submodulo, String modulo, JButton submoduloBtn) {
        
        // Cambiar a la disposición inicial de cuadroDetalles
        cuadroDetalles.setLayout(new GridLayout(7, 2, 5, 5));
        
        // Borra todos los componentes
        cuadroDetalles.removeAll();
   
        if (modulo.equals("Insertar datos")) {
                    
            if (submodulo.equals("Insertar usuario")) { 
                ColorearBoton(submodulo, submoduloBtn);
                
                cuadroDetalles.add(new JLabel("Nombre del local donante:"));
                cuadroDetalles.add(proxyvista.getInsertarUsuarioGUI().getNombreLocalField());

                cuadroDetalles.add(new JLabel("Tipo del local donante:"));
                cuadroDetalles.add(proxyvista.getInsertarUsuarioGUI().getTipoLocalField());

                cuadroDetalles.add(new JLabel("Email del local donante:"));
                cuadroDetalles.add(proxyvista.getInsertarUsuarioGUI().getEmailField());

                cuadroDetalles.add(new JLabel("Teléfono del local donante:"));
                cuadroDetalles.add(proxyvista.getInsertarUsuarioGUI().getTelefonoField());

                cuadroDetalles.add(new JLabel("Dirección del local donante:"));
                cuadroDetalles.add(proxyvista.getInsertarUsuarioGUI().getDireccionField());
            } 
            else if (submodulo.equals("Insertar excedente")) {
                ColorearBoton(submodulo, submoduloBtn);
                
                cuadroDetalles.add(new JLabel("ID del local donante:"));
                cuadroDetalles.add(proxyvista.getInsertarExcedenteGUI().getIdLocalField());

                cuadroDetalles.add(new JLabel("Descripción del excedente:"));
                cuadroDetalles.add(proxyvista.getInsertarExcedenteGUI().getDescripcionExcedenteField());

                cuadroDetalles.add(new JLabel("Cantidad del excedente:"));
                cuadroDetalles.add(proxyvista.getInsertarExcedenteGUI().getCantidadExcedenteField());

                cuadroDetalles.add(new JLabel("Unidad de medida del excedente:"));
                cuadroDetalles.add(proxyvista.getInsertarExcedenteGUI().getUnidadMedidaField());

                cuadroDetalles.add(new JLabel("Fecha de elaboración del excedente:  (D/M/A o D-M-A)"));
                cuadroDetalles.add(proxyvista.getInsertarExcedenteGUI().getFechaElaboracionField());

                cuadroDetalles.add(new JLabel("Fecha de caducidad del excedente:  (D/M/A o D-M-A)"));
                cuadroDetalles.add(proxyvista.getInsertarExcedenteGUI().getFechaCaducidadField());

                cuadroDetalles.add(new JLabel("Estado del excedente:"));
                cuadroDetalles.add(proxyvista.getInsertarExcedenteGUI().getEstadoExcedenteCombo());
            }
            else if (submodulo.equals("Insertar donación")) {
                ColorearBoton(submodulo, submoduloBtn);
                
                cuadroDetalles.add(new JLabel("ID del excedente:"));
                cuadroDetalles.add(proxyvista.getInsertarDonacionGUI().getIdExcedenteField());

                cuadroDetalles.add(new JLabel("ID del local donante:"));
                cuadroDetalles.add(proxyvista.getInsertarDonacionGUI().getIdLocalDonanteField());

                cuadroDetalles.add(new JLabel("Fecha de asignación:  (D/M/A o D-M-A)"));
                cuadroDetalles.add(proxyvista.getInsertarDonacionGUI().getFechaAsignacionField());

                cuadroDetalles.add(new JLabel("Fecha de recolección:  (D/M/A o D-M-A)"));
                cuadroDetalles.add(proxyvista.getInsertarDonacionGUI().getFechaRecoleccionField());

                cuadroDetalles.add(new JLabel("Estado de la donación:"));
                cuadroDetalles.add(proxyvista.getInsertarDonacionGUI().getEstadoDonacionCombo());
            }
            else if (submodulo.equals("Insertar transporte")) {
                ColorearBoton(submodulo, submoduloBtn);
                
                cuadroDetalles.add(new JLabel("ID de la donación:"));
                cuadroDetalles.add(proxyvista.getInsertarTransporteGUI().getIdDonacionField());

                cuadroDetalles.add(new JLabel("Descripción del vehículo:"));
                cuadroDetalles.add(proxyvista.getInsertarTransporteGUI().getDescripcionVehiculoField());

                cuadroDetalles.add(new JLabel("Nombre del conductor:"));
                cuadroDetalles.add(proxyvista.getInsertarTransporteGUI().getNombreConductorField());

                cuadroDetalles.add(new JLabel("Fecha de salida del vehículo:  (D/M/A o D-M-A)"));
                cuadroDetalles.add(proxyvista.getInsertarTransporteGUI().getFechaSalidaVehiculoField());

                cuadroDetalles.add(new JLabel("Fecha de entrega del vehículo:  (D/M/A o D-M-A)"));
                cuadroDetalles.add(proxyvista.getInsertarTransporteGUI().getFechaEntregaVehiculoField());

                cuadroDetalles.add(new JLabel("Estado:"));
                cuadroDetalles.add(proxyvista.getInsertarTransporteGUI().getEstadoTransporteCombo());                
            }
            else if (submodulo.equals("Insertar recompensa")) {
                ColorearBoton(submodulo, submoduloBtn);
                
                cuadroDetalles.add(new JLabel("ID de la donación:"));
                cuadroDetalles.add(proxyvista.getInsertarRecompensaGUI().getIdDonacionRecompensaField());

                cuadroDetalles.add(new JLabel("ID del local donante:"));
                cuadroDetalles.add(proxyvista.getInsertarRecompensaGUI().getIdLocalDonanteRecompensaField());

                cuadroDetalles.add(new JLabel("Puntos obtenidos por la donación:"));
                cuadroDetalles.add(proxyvista.getInsertarRecompensaGUI().getPuntosObtenidosField());

                cuadroDetalles.add(new JLabel("Fecha de otorgación:  (D/M/A o D-M-A)"));
                cuadroDetalles.add(proxyvista.getInsertarRecompensaGUI().getFechaOtorgacionField());
            }
          
        } else if (modulo.equals("Obtener datos")) {           
            if(submodulo.equals("Obtener excedentes por estado")){
                ColorearBoton(submodulo, submoduloBtn);
                
                // Cambiar la disposición de cuadroDetalles
                cuadroDetalles.setLayout(new BoxLayout(cuadroDetalles, BoxLayout.Y_AXIS));
                
                JPanel panelSuperior = new JPanel(new FlowLayout(FlowLayout.LEFT));
                JLabel labelSeleccionarAjuste = new JLabel("Seleccionar ajuste de la tabla:");
                comboBoxOpcionesAjuste = new JComboBox<>(new String[]{
                    "Mostrar tabla con los 3 estados",
                    "Mostrar tabla con estado 'Asignado'",
                    "Mostrar tabla con estado 'Disponible'",
                    "Mostrar tabla con estado 'Entregado'"
                });
                
                panelSuperior.add(labelSeleccionarAjuste);
                panelSuperior.add(comboBoxOpcionesAjuste);
                
                tableModel = new DefaultTableModel(new String[]{
                    "ExcedenteID", "UsuarioID", "Descripcion", "Cantidad", "UnidadMedida", "FechaCreacion", "FechaCaducidad", "Estado"
                }, 0);
                
                tableExcedentes = new JTable(tableModel);
                tableExcedentes.setRowHeight(30); // Reducir altura de las filas para ajustarse
                
                JScrollPane scrollPane = new JScrollPane(tableExcedentes);
                scrollPane.setPreferredSize(new Dimension(400, 350)); // Tamaño ajustado

                JPanel panelInferior = new JPanel(new FlowLayout(FlowLayout.CENTER));
                buttonActualizar = new JButton("ACTUALIZAR AJUSTE DE LA TABLA");
                panelInferior.add(buttonActualizar);
                                
                cuadroDetalles.add(panelSuperior);    // ComboBox en la parte superior
                cuadroDetalles.add(scrollPane);      // Tabla en el centro
                cuadroDetalles.add(panelInferior);    // Botón en la parte inferior
                
                buttonActualizar.addActionListener(e -> actualizarTablas(submodulo, textFieldNumero, comboBoxOpcionesAjuste, tableModel));
            }
            else if (submodulo.equals("Obtener donaciones por estado")) {
                ColorearBoton(submodulo, submoduloBtn);
                
                // Cambiar la disposición de cuadroDetalles
                cuadroDetalles.setLayout(new BoxLayout(cuadroDetalles, BoxLayout.Y_AXIS));
                
                JPanel panelSuperior = new JPanel(new FlowLayout(FlowLayout.LEFT));
                JLabel labelSeleccionarAjuste = new JLabel("Seleccionar ajuste de la tabla:");
                comboBoxOpcionesAjuste = new JComboBox<>(new String[]{
                    "Mostrar tabla con los 2 estados",
                    "Mostrar tabla con estado 'Asignado'",
                    "Mostrar tabla con estado 'Recolectado'"
                });  
                panelSuperior.add(labelSeleccionarAjuste);
                panelSuperior.add(comboBoxOpcionesAjuste);
                
                tableModel = new DefaultTableModel(new String[]{
                    "DonacionID", "ExcedenteID", "OrganizacionID", "FechaAsignacion", "FechaRecoleccion", "Estado"
                }, 0);
                
                tableDonaciones = new JTable(tableModel);                
                tableDonaciones.setRowHeight(30); // Reducir altura de las filas para ajustarse
                JScrollPane scrollPane = new JScrollPane(tableDonaciones);
                scrollPane.setPreferredSize(new Dimension(400, 350)); // Tamaño ajustado
                
                JPanel panelInferior = new JPanel(new FlowLayout(FlowLayout.CENTER));
                buttonActualizar = new JButton("ACTUALIZAR AJUSTE DE LA TABLA");
                panelInferior.add(buttonActualizar);
                                
                cuadroDetalles.add(panelSuperior);    // ComboBox en la parte superior
                cuadroDetalles.add(scrollPane);      // Tabla en el centro
                cuadroDetalles.add(panelInferior);    // Botón en la parte inferior               
                
                buttonActualizar.addActionListener(e -> actualizarTablas(submodulo, textFieldNumero, comboBoxOpcionesAjuste, tableModel));            
            }
            else if (submodulo.equals("Obtener recompensas por usuario")){
                ColorearBoton(submodulo, submoduloBtn);
                
                // Cambiar la disposición de cuadroDetalles
                cuadroDetalles.setLayout(new BoxLayout(cuadroDetalles, BoxLayout.Y_AXIS));
                
                JPanel panelSuperior = new JPanel(new FlowLayout(FlowLayout.LEFT));
                JLabel labelSeleccionarAjuste = new JLabel("Ingresar número de ID del local donante:");
                textFieldNumero = new JTextField(10);  // 10 es el número de caracteres visibles en el campo
                panelSuperior.add(labelSeleccionarAjuste);
                panelSuperior.add(textFieldNumero);
                
                tableModel = new DefaultTableModel(new String[]{
                    "RecompensaID", "DonacionID", "UsuarioID", "Puntos", "FechaOtorgacion"
                }, 0);
                
                tableRecompensas = new JTable(tableModel);
                tableRecompensas.setRowHeight(30); // Reducir altura de las filas para ajustarse
                JScrollPane scrollPane = new JScrollPane(tableRecompensas);
                scrollPane.setPreferredSize(new Dimension(400, 350)); // Tamaño ajustado 
                
                JPanel panelInferior = new JPanel(new FlowLayout(FlowLayout.CENTER));
                buttonActualizar = new JButton("ACTUALIZAR AJUSTE DE LA TABLA");
                panelInferior.add(buttonActualizar);  
                                
                cuadroDetalles.add(panelSuperior);    // ComboBox en la parte superior
                cuadroDetalles.add(scrollPane);      // Tabla en el centro
                cuadroDetalles.add(panelInferior);    // Botón en la parte inferior                               

                buttonActualizar.addActionListener(e -> actualizarTablas(submodulo, textFieldNumero, comboBoxOpcionesAjuste, tableModel));
            }
            else if (submodulo.equals("Obtener rangos por tipo de recompensa")){  
                ColorearBoton(submodulo, submoduloBtn);
                
                // Cambiar la disposición de cuadroDetalles
                cuadroDetalles.setLayout(new BoxLayout(cuadroDetalles, BoxLayout.Y_AXIS));
                
                JPanel panelSuperior = new JPanel(new FlowLayout(FlowLayout.LEFT));
                JLabel labelSeleccionarAjuste = new JLabel("Seleccionar ajuste de la tabla:");
                comboBoxOpcionesAjuste = new JComboBox<>(new String[]{
                    "Mostrar tabla con los 2 tipos de recompensas",
                    "Mostrar tabla con tipo de recompensa 'Física'",
                    "Mostrar tabla con tipo de recompensa 'No Física'"
                });
                
                panelSuperior.add(labelSeleccionarAjuste);
                panelSuperior.add(comboBoxOpcionesAjuste); 
                
                tableModel = new DefaultTableModel(new String[]{
                    "DetallesID", "MinPuntos", "MaxPuntos", "TipoRecompensa", "Descripcion"
                }, 0);
                
                tableRangos = new JTable(tableModel);
                tableRangos.setRowHeight(30); // Reducir altura de las filas para ajustarse
                JScrollPane scrollPane = new JScrollPane(tableRangos);
                scrollPane.setPreferredSize(new Dimension(400, 350)); // Tamaño ajustado                 

                JPanel panelInferior = new JPanel(new FlowLayout(FlowLayout.CENTER));
                buttonActualizar = new JButton("ACTUALIZAR AJUSTE DE LA TABLA");
                panelInferior.add(buttonActualizar);
                
                cuadroDetalles.add(panelSuperior);    // ComboBox en la parte superior
                cuadroDetalles.add(scrollPane);      // Tabla en el centro
                cuadroDetalles.add(panelInferior);    // Botón en la parte inferior                                     

                buttonActualizar.addActionListener(e -> actualizarTablas(submodulo, textFieldNumero, comboBoxOpcionesAjuste, tableModel));            
            }
            else if (submodulo.equals("Obtener transporte por estado")){
                ColorearBoton(submodulo, submoduloBtn);
                
                // Cambiar la disposición de cuadroDetalles
                cuadroDetalles.setLayout(new BoxLayout(cuadroDetalles, BoxLayout.Y_AXIS));
                
                JPanel panelSuperior = new JPanel(new FlowLayout(FlowLayout.LEFT));
                JLabel labelSeleccionarAjuste = new JLabel("Seleccionar ajuste de la tabla:");
                comboBoxOpcionesAjuste = new JComboBox<>(new String[]{
                    "Mostrar tabla con los 3 estados",
                    "Mostrar tabla con estado 'Completado'",
                    "Mostrar tabla con estado 'En Progreso'",
                    "Mostrar tabla con estado 'Planificado'"
                });
                
                panelSuperior.add(labelSeleccionarAjuste);
                panelSuperior.add(comboBoxOpcionesAjuste); 
                
                tableModel = new DefaultTableModel(new String[]{
                    "RutaID", "DonacionID", "Vehiculo", "Conductor", "FechaInicio", "FechaFin", "Estado"
                }, 0);
                
                tableTransportes = new JTable(tableModel);    
                tableTransportes.setRowHeight(30); // Reducir altura de las filas para ajustarse
                JScrollPane scrollPane = new JScrollPane(tableTransportes);
                scrollPane.setPreferredSize(new Dimension(400, 350)); // Tamaño ajustado   
               
                JPanel panelInferior = new JPanel(new FlowLayout(FlowLayout.CENTER));
                buttonActualizar = new JButton("ACTUALIZAR AJUSTE DE LA TABLA");
                panelInferior.add(buttonActualizar);
                               
                cuadroDetalles.add(panelSuperior);    // ComboBox en la parte superior
                cuadroDetalles.add(scrollPane);      // Tabla en el centro
                cuadroDetalles.add(panelInferior);    // Botón en la parte inferior                                                     
                
                buttonActualizar.addActionListener(e -> actualizarTablas(submodulo, textFieldNumero, comboBoxOpcionesAjuste, tableModel));
            }  
        }
        // Actualizamos el layout
        cuadroDetalles.revalidate();
        // Refrescamos el componente visualmente
        cuadroDetalles.repaint();
    }
    
    private void agregarDatos(){
        proxyvista.agregarDatosProxy(submoduloActual, new FacadeControlador());
    }
    
    private void limpiarCampos(){
        proxyvista.limpiarCamposProxy(submoduloActual);
    }
    
    private void actualizarTablas(String submodulo, JTextField textFieldNumero, JComboBox<String> comboBoxOpcionesAjuste,DefaultTableModel tableModel){
        if (submodulo.equals("Obtener excedentes por estado")){
            observervista = new ObserverVista("'Excedentes'");
            sujetoobserver.añadir(observervista);        
            sujetoobserver.actualizar(submodulo, textFieldNumero, comboBoxOpcionesAjuste, new FacadeControlador(), tableModel);
            sujetoobserver.eliminar(observervista);
        }
        
        if (submodulo.equals("Obtener donaciones por estado")){
            observervista = new ObserverVista("'Donaciones'");
            sujetoobserver.añadir(observervista);            
            sujetoobserver.actualizar(submodulo, textFieldNumero, comboBoxOpcionesAjuste, new FacadeControlador(), tableModel);
            sujetoobserver.eliminar(observervista);
        }
        
        if (submodulo.equals("Obtener recompensas por usuario")){
            observervista = new ObserverVista("'Recompensas'");
            sujetoobserver.añadir(observervista);            
            sujetoobserver.actualizar(submodulo, textFieldNumero, comboBoxOpcionesAjuste, new FacadeControlador(), tableModel);
            sujetoobserver.eliminar(observervista);
        }  
        
        if (submodulo.equals("Obtener rangos por tipo de recompensa")){
            observervista = new ObserverVista("'DetallesDeRecompensas'");
            sujetoobserver.añadir(observervista);            
            sujetoobserver.actualizar(submodulo, textFieldNumero, comboBoxOpcionesAjuste, new FacadeControlador(), tableModel);
            sujetoobserver.eliminar(observervista);
        }
        
        if (submodulo.equals("Obtener transporte por estado")){
            observervista = new ObserverVista("'Transporte'");
            sujetoobserver.añadir(observervista);            
            sujetoobserver.actualizar(submodulo, textFieldNumero, comboBoxOpcionesAjuste, new FacadeControlador(), tableModel);
            sujetoobserver.eliminar(observervista);
        }
    }
}