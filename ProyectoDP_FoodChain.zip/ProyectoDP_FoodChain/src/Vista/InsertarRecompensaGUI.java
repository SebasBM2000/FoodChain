package Vista;

import Controlador.FacadeControlador;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class InsertarRecompensaGUI extends JPanel {
    
    private JTextField idDonacionRecompensaField;
    private JTextField idLocalDonanteRecompensaField;
    private JTextField puntosObtenidosField;
    private JTextField fechaOtorgacionField;
    
    public InsertarRecompensaGUI(){
        this.idDonacionRecompensaField = new JTextField(20);
        this.idLocalDonanteRecompensaField = new JTextField(20);
        this.puntosObtenidosField = new JTextField(20);
        this.fechaOtorgacionField = new JTextField(20);        
    }
    
    protected void insertarDatosRecompensa(FacadeControlador facadecontrolador){
        if (idDonacionRecompensaField.getText().isEmpty() || idLocalDonanteRecompensaField.getText().isEmpty() ||
                puntosObtenidosField.getText().isEmpty() || fechaOtorgacionField.getText().isEmpty()) {
            
            JOptionPane.showMessageDialog(this, "No se pudo agregar a la base de datos, por favor complete el cuadro de detalles.");
            return;
        }
        
        try {
            facadecontrolador.insertarRecompensa(
                    Integer.parseInt(idDonacionRecompensaField.getText()),
                    Integer.parseInt(idLocalDonanteRecompensaField.getText()),
                    Integer.parseInt(puntosObtenidosField.getText()),
                    fechaOtorgacionField.getText()
            );
            
            JOptionPane.showMessageDialog(this, "Agregando los datos a la tabla Recompensas...");
        
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al agregar recompensa: " + e.getMessage());
        }        
    }
    
    protected void eliminarDatosRecompensa(){
        idDonacionRecompensaField.setText("");
        idLocalDonanteRecompensaField.setText("");
        puntosObtenidosField.setText("");
        fechaOtorgacionField.setText("");        
    }
    
    public JTextField getIdDonacionRecompensaField() {
        return this.idDonacionRecompensaField;
    }

    public JTextField getIdLocalDonanteRecompensaField() {
        return this.idLocalDonanteRecompensaField;
    }

    public JTextField getPuntosObtenidosField() {
        return this.puntosObtenidosField;
    }

    public JTextField getFechaOtorgacionField() {
        return this.fechaOtorgacionField;
    }
}

