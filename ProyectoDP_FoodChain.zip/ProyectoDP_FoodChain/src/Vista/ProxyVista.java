package Vista;

import Controlador.FacadeControlador;

public class ProxyVista implements InterfaceProxy{
    
    private ObjetoRealProxy objetorealproxy;
    private InsertarUsuarioGUI insertarUsuarioGUI;
    private InsertarExcedenteGUI insertarExcedenteGUI;
    private InsertarDonacionGUI insertarDonacionGUI;
    private InsertarTransporteGUI insertarTransporteGUI;
    private InsertarRecompensaGUI insertarRecompensaGUI;
      
    public ProxyVista(){
        this.objetorealproxy = new ObjetoRealProxy();
        this.insertarUsuarioGUI = new InsertarUsuarioGUI();
        this.insertarExcedenteGUI = new InsertarExcedenteGUI();
        this.insertarDonacionGUI = new InsertarDonacionGUI();
        this.insertarTransporteGUI = new InsertarTransporteGUI();
        this.insertarRecompensaGUI = new InsertarRecompensaGUI();
    }
       
    @Override
    public void agregarDatosProxy(String submoduloActual, FacadeControlador facadecontrolador) {
        if (submoduloActual.equals("Insertar usuario")) {
            insertarUsuarioGUI.insertarDatosUsuario(facadecontrolador);
            objetorealproxy.agregarDatosProxy(submoduloActual,facadecontrolador);
        }       
        else if (submoduloActual.equals("Insertar excedente")) {
            insertarExcedenteGUI.insertarDatosExcedente(facadecontrolador);
            objetorealproxy.agregarDatosProxy(submoduloActual,facadecontrolador);            
        } 
        else if (submoduloActual.equals("Insertar donación")) {
            insertarDonacionGUI.insertarDatosDonacion(facadecontrolador);
            objetorealproxy.agregarDatosProxy(submoduloActual,facadecontrolador);            
        } 
        else if (submoduloActual.equals("Insertar transporte")) {
            insertarTransporteGUI.insertarDatosTransporte(facadecontrolador);
            objetorealproxy.agregarDatosProxy(submoduloActual,facadecontrolador);            
        }
        else if (submoduloActual.equals("Insertar recompensa")) {
            insertarRecompensaGUI.insertarDatosRecompensa(facadecontrolador);
            objetorealproxy.agregarDatosProxy(submoduloActual,facadecontrolador);            
        }
    }
    
    protected void limpiarCamposProxy(String submoduloActual) {
        
        if (submoduloActual.equals("Insertar usuario")) {
            insertarUsuarioGUI.eliminarDatosUsuario();
        }        
        else if (submoduloActual.equals("Insertar excedente")) {
            insertarExcedenteGUI.eliminarDatosExcedente();
        }       
        else if (submoduloActual.equals("Insertar donación")) {
            insertarDonacionGUI.eliminarDatosDonacion();
        }       
        else if (submoduloActual.equals("Insertar transporte")) {
            insertarTransporteGUI.eliminarDatosTransporte();
        }      
        else if (submoduloActual.equals("Insertar recompensa")) {
            insertarRecompensaGUI.eliminarDatosRecompensa();
        }
    } 
 
    public InsertarUsuarioGUI getInsertarUsuarioGUI() {
        return this.insertarUsuarioGUI;
    }

    public InsertarExcedenteGUI getInsertarExcedenteGUI() {
        return this.insertarExcedenteGUI;
    }

    public InsertarDonacionGUI getInsertarDonacionGUI() {
        return this.insertarDonacionGUI;
    }

    public InsertarTransporteGUI getInsertarTransporteGUI() {
        return this.insertarTransporteGUI;
    }

    public InsertarRecompensaGUI getInsertarRecompensaGUI() {
        return this.insertarRecompensaGUI;
    }

}
