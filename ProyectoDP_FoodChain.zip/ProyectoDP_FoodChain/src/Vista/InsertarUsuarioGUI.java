package Vista;

import Controlador.FacadeControlador;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class InsertarUsuarioGUI extends JPanel {
    
    private JTextField nombreLocalField;
    private JTextField tipoLocalField;
    private JTextField emailField;
    private JTextField telefonoField;
    private JTextField direccionField;
    
    public InsertarUsuarioGUI(){
        this.nombreLocalField = new JTextField(20);
        this.tipoLocalField = new JTextField(20);
        this.emailField = new JTextField(20);
        this.telefonoField = new JTextField(20);
        this.direccionField = new JTextField(20);
    }    
    
    protected void insertarDatosUsuario(FacadeControlador facadecontrolador) {
        if (nombreLocalField.getText().isEmpty() || tipoLocalField.getText().isEmpty() ||
                emailField.getText().isEmpty() || telefonoField.getText().isEmpty() ||
                direccionField.getText().isEmpty()) {
            
            JOptionPane.showMessageDialog(this, "No se pudo agregar a la base de datos, por favor complete el cuadro de detalles.");
            return;
        }
            
        try {
            facadecontrolador.insertarUsuario(
                    nombreLocalField.getText(),
                    tipoLocalField.getText(),
                    emailField.getText(),
                    telefonoField.getText(),
                    direccionField.getText()
            );   
            
            JOptionPane.showMessageDialog(this, "Agregando los datos a la tabla Usuarios...");
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al agregar a la base de datos: " + e.getMessage());
        }
    }
    
    protected void eliminarDatosUsuario(){        
        nombreLocalField.setText("");
        tipoLocalField.setText("");
        emailField.setText("");
        telefonoField.setText("");
        direccionField.setText("");     
    }
    
    public JTextField getNombreLocalField() {
        return this.nombreLocalField;
    }

    public JTextField getTipoLocalField() {
        return this.tipoLocalField;
    }

    public JTextField getEmailField() {
        return this.emailField;
    }

    public JTextField getTelefonoField() {
        return this.telefonoField;
    }

    public JTextField getDireccionField() {
        return this.direccionField;
    }
}