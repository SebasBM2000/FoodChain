package Vista;

import Controlador.FacadeControlador;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class InsertarDonacionGUI extends JPanel {

    private JTextField idExcedenteField;
    private JTextField idLocalDonanteField;
    private JTextField fechaAsignacionField;
    private JTextField fechaRecoleccionField;
    private JComboBox<String> estadoDonacionCombo; 
    
    public InsertarDonacionGUI(){
        this.idExcedenteField = new JTextField(20);
        this.idLocalDonanteField = new JTextField(20);
        this.fechaAsignacionField = new JTextField(20);
        this.fechaRecoleccionField = new JTextField(20);
        this.estadoDonacionCombo = new JComboBox<>(new String[]{"Asignado", "Recolectado"});        
    }

    protected void insertarDatosDonacion(FacadeControlador facadecontrolador){
        if (idExcedenteField.getText().isEmpty() || idLocalDonanteField.getText().isEmpty() ||
                fechaAsignacionField.getText().isEmpty() || fechaRecoleccionField.getText().isEmpty()) {
            
            JOptionPane.showMessageDialog(this, "No se pudo agregar a la base de datos, por favor complete el cuadro de detalles.");
            return;
        }
        
        try {
            facadecontrolador.insertarDonacion(
                    Integer.parseInt(idExcedenteField.getText()),
                    Integer.parseInt(idLocalDonanteField.getText()),
                    fechaAsignacionField.getText(),
                    fechaRecoleccionField.getText(),
                    String.valueOf(estadoDonacionCombo.getSelectedItem())
            );
            
            JOptionPane.showMessageDialog(this, "Agregando los datos a la tabla Donaciones...");
        
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al agregar a la base de datos: " + e.getMessage());
        }        
    }
    
    protected void eliminarDatosDonacion(){
        idExcedenteField.setText("");
        idLocalDonanteField.setText("");
        fechaAsignacionField.setText("");
        fechaRecoleccionField.setText("");
        estadoDonacionCombo.setSelectedIndex(0);        
    }

    public JTextField getIdExcedenteField() {
        return this.idExcedenteField;
    }

    public JTextField getIdLocalDonanteField() {
        return this.idLocalDonanteField;
    }

    public JTextField getFechaAsignacionField() {
        return this.fechaAsignacionField;
    }

    public JTextField getFechaRecoleccionField() {
        return this.fechaRecoleccionField;
    }

    public JComboBox<String> getEstadoDonacionCombo() {
        return this.estadoDonacionCombo;
    }
}
