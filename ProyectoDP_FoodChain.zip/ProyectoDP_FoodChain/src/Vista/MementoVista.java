package Vista;

public class MementoVista {
    private String colorearboton;

    public MementoVista(String colorearboton) {
        this.colorearboton = colorearboton;
    }

    public String getEliminarColor() {
        colorearboton = "predeterminado";
        return colorearboton;
    }

}