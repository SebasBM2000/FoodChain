package Vista;

import Controlador.FacadeControlador;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class ObjetoRealProxy extends JPanel implements InterfaceProxy {
    
    @Override
    public void agregarDatosProxy(String submoduloActual, FacadeControlador facadecontrolador) {
            JOptionPane.showMessageDialog(this,"El proceso ha finalizado que tenga un buen día.");
    }
    
}
