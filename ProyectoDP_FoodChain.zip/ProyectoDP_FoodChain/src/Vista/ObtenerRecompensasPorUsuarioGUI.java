package Vista;

import Controlador.FacadeControlador;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

public class ObtenerRecompensasPorUsuarioGUI extends JPanel {
    
    // Método para validar que el número sea un entero positivo
    private int validarNumeroPositivo(String textoNumero) {
        int numero = 0;

        try {
            numero = Integer.parseInt(textoNumero);
            if (numero <= 0) {
                JOptionPane.showMessageDialog(this, "El número debe ser un entero positivo.");
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "El valor ingresado no es un número entero positivo.");
        }
        return numero;
    }
    
    // Método para actualizar la tabla según el número ingresado
    protected void actualizarTablaRecompensas(JTextField textFieldNumero, FacadeControlador facadecontrolador, DefaultTableModel tableModel) {
        tableModel.setRowCount(0); // Limpiar la tabla
        
        // Obtener el número ingresado
        String textoNumero = textFieldNumero.getText();
        
        int numero = validarNumeroPositivo(textoNumero); 
        
        if (numero > 0) {
            // Redirigir la salida de consola para capturar los datos impresos
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            PrintStream originalOut = System.out;
            PrintStream printStream = new PrintStream(baos);
            System.setOut(printStream);

            // Llamar al controlador para obtener las recompensas por usuario
            facadecontrolador.obtenerRecompensasPorUsuario(numero);

            // Restaurar la salida de consola
            System.setOut(originalOut);

            // Procesar la salida capturada
            String[] filas = baos.toString().split("\n");
            Object[] filaActual = new Object[5];
            int index = 0;

            // Recorrer las filas y agregarlas a la tabla
            for (String linea : filas) {
                String[] partes = linea.split(": ");
                if (partes.length > 1) {
                    filaActual[index] = partes[1];
                    index++;
                    if (index == 5) {
                        tableModel.addRow(filaActual);
                        filaActual = new Object[5];
                        index = 0;
                    }
                }
            }
            JOptionPane.showMessageDialog(null, "Se ha actualizado correctamente la tabla 'Recompensas' en el cuadro de detalles");
        }
    }
}
