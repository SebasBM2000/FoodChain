package Modelo;

import java.sql.PreparedStatement;
import java.sql.SQLException;

//Esta clase cumple el rol de implementación concreta de IStoredProcedure para la tabla InsertarRecompensaProcedure
//Este clase cumple el rol de un subsistema de la clase FacadeControlador
public class InsertarRecompensaProcedure extends ConexionStoredProcedure implements IStoredProcedure {
    
    private int donacionID;
    private int usuarioID;
    private int puntos;
    private String fechaOtorgacion;

    public InsertarRecompensaProcedure(int donacionID, int usuarioID, int puntos, String fechaOtorgacion) {
        this.donacionID = donacionID;
        this.usuarioID = usuarioID;
        this.puntos = puntos;
        this.fechaOtorgacion = fechaOtorgacion;
    }
    
    //Método que forma parte del subsistema
    @Override
    public void ejecutar() throws SQLException {
        String sql = "EXEC InsertarRecompensa ?, ?, ?, ?";
        PreparedStatement statement = conexion.prepareStatement(sql);
        statement.setInt(1, donacionID);
        statement.setInt(2, usuarioID);
        statement.setInt(3, puntos);
        statement.setString(4, fechaOtorgacion);
        statement.executeUpdate();
    }
}