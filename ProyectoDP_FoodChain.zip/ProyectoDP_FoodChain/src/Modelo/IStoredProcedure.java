package Modelo;

import java.sql.SQLException;

// Interfaz para procedimientos almacenados
public interface IStoredProcedure {
    void ejecutar() throws SQLException;
}