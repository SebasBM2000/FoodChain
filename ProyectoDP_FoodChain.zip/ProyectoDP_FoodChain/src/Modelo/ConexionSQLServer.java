package Modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionSQLServer {
    
    // Variable estática para almacenar la única instancia de la clase
    private static ConexionSQLServer instancia;
    
    // Variable para la conexión con la base de datos
    private Connection conexion;
    
    // Datos de conexión a la base de datos
    private final String url = "jdbc:sqlserver://localhost:1433;database=ProyectoDP_FoodChain;integratedSecurity=true;encrypt=false";

    // Constructor privado para evitar instanciación externa (Patrón Singleton)
    private ConexionSQLServer() {
        try {
            // Establecemos la conexión.
            conexion = DriverManager.getConnection(url);
            System.out.println("Conexión exitosa a la base de datos SQL Server.");
        } catch (SQLException e) {
            // Capturamos y mostramos cualquier error en la conexión.
            System.out.println("Error en la conexión: " + e.getMessage());
        }
    }
    
    // Método estático que devuelve la única instancia de la clase (Patrón Singleton)
    public static ConexionSQLServer getInstancia() {
        if (instancia == null) {
            // Si la instancia no existe, la creamos
            instancia = new ConexionSQLServer();
        }
        // Retornamos la instancia única.
        return instancia;
    }
    
    // Método para obtener la conexión y usarla en otros componentes (Vista o Controlador)
    public Connection getConexion() {
        return conexion;
    }  
}