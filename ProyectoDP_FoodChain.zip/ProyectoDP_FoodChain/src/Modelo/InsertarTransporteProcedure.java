package Modelo;

import java.sql.PreparedStatement;
import java.sql.SQLException;

//Esta clase cumple el rol de implementación concreta de IStoredProcedure para la tabla InsertarTransporteProcedure
//Este clase cumple el rol de un subsistema de la clase FacadeControlador
public class InsertarTransporteProcedure extends ConexionStoredProcedure implements IStoredProcedure {
    
    private int donacionID;
     private String vehiculo;
    private String conductor;
    private String fechaInicio;
    private String fechaFin;
    private String estado;

    public InsertarTransporteProcedure(int donacionID, String vehiculo, String conductor, String fechaInicio, String fechaFin, String estado) {
        this.donacionID = donacionID;
        this.vehiculo = vehiculo;
        this.conductor = conductor;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.estado = estado;
    }

    //Método que forma parte del subsistema
    @Override
    public void ejecutar() throws SQLException {
        String sql = "EXEC InsertarTransporte ?, ?, ?, ?, ?, ?";
        PreparedStatement statement = conexion.prepareStatement(sql);
        statement.setInt(1, donacionID);
        statement.setString(3, vehiculo);
        statement.setString(2, conductor);
        statement.setString(4, fechaInicio);
        statement.setString(5, fechaFin);
        statement.setString(6, estado);
        statement.executeUpdate();
    }
}