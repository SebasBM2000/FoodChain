package Modelo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

//Esta clase cumple el rol de implementación concreta de IStoredProcedure para la tabla ObtenerDonacionesPorEstadoProcedure
//Este clase cumple el rol de un subsistema de la clase FacadeControlador
public class ObtenerDonacionesPorEstadoProcedure extends ConexionStoredProcedure implements IStoredProcedure {
    
    private String estado;

    public ObtenerDonacionesPorEstadoProcedure(String estado) {
        this.estado = estado;
    }

    //Método que forma parte del subsistema    
    @Override
    public void ejecutar() throws SQLException {
        String sql = "EXEC ObtenerDonacionesPorEstado ?";
        PreparedStatement statement = conexion.prepareStatement(sql);
        statement.setString(1, estado);
        ResultSet resultSet = statement.executeQuery();

        // Procesar el resultado
        while (resultSet.next()) {
            System.out.println("DonacionID: " + resultSet.getInt("DonacionID"));
            System.out.println("ExcedenteID: " + resultSet.getInt("ExcedenteID"));
            System.out.println("OrganizacionID: " + resultSet.getInt("OrganizacionID"));
            System.out.println("FechaAsignacion: " + resultSet.getString("FechaAsignacion"));
            System.out.println("FechaRecoleccion: " + resultSet.getString("FechaRecoleccion"));
            System.out.println("Estado: " + resultSet.getString("Estado"));
            
        }
    }
}