package Modelo;

import java.sql.PreparedStatement;
import java.sql.SQLException;

//Esta clase cumple el rol de implementación concreta de IStoredProcedure para la tabla InsertarUsuarioProcedure
//Este clase cumple el rol de un subsistema de la clase FacadeControlador
public class InsertarUsuarioProcedure extends ConexionStoredProcedure implements IStoredProcedure {

    private String nombre;
    private String tipoUsuario;
    private String email;
    private String telefono;
    private String direccion;

    public InsertarUsuarioProcedure(String nombre, String tipoUsuario, String email, String telefono, String direccion) {
        this.nombre = nombre;
        this.tipoUsuario = tipoUsuario;
        this.email = email;
        this.telefono = telefono;
        this.direccion = direccion;
    }

    //Método que forma parte del subsistema
    @Override
    public void ejecutar() throws SQLException {
        String sql = "EXEC InsertarUsuario ?, ?, ?, ?, ?";
        PreparedStatement statement = conexion.prepareStatement(sql);
        statement.setString(1, nombre);
        statement.setString(2, tipoUsuario);
        statement.setString(3, email);
        statement.setString(4, telefono);
        statement.setString(5, direccion);

        // Ejecuta el procedimiento almacenado
        statement.executeUpdate();
    }
}