package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

// Clase abstracta para definir el prototipo de operación (Patrón Prototype)
public abstract class ConexionStoredProcedure implements Cloneable {

    // Variable protegida para la conexión a la base de datos
    protected Connection conexion;

    // Constructor que recibe la conexión a la base de datos
    public ConexionStoredProcedure() {
        // Se obtiene la conexión desde el Singleton
        this.conexion = ConexionSQLServer.getInstancia().getConexion();
    }

    // Método abstracto que cada subclase deberá implementar para ejecutar la operación específica
    public abstract void ejecutar() throws SQLException;

    // Método para clonar el prototipo
    @Override
    public ConexionStoredProcedure clone() {
        try {
            return (ConexionStoredProcedure) super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            return null;
        }
    }
}