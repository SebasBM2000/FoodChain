package Modelo;

import java.sql.PreparedStatement;
import java.sql.SQLException;

//Esta clase cumple el rol de implementación concreta de IStoredProcedure para la tabla InsertarDonacionProcedure
//Este clase cumple el rol de un subsistema de la clase FacadeControlador
public class InsertarDonacionProcedure extends ConexionStoredProcedure implements IStoredProcedure {
    
    private int excedenteID;
    private int organizacionID;
    private String fechaAsignacion;
    private String fechaRecoleccion;
    private String estado;

    public InsertarDonacionProcedure(int excedenteID, int organizacionID, String fechaAsignacion, String fechaRecoleccion, String estado) {
        this.excedenteID = excedenteID;
        this.organizacionID = organizacionID;
        this.fechaAsignacion = fechaAsignacion;
        this.fechaRecoleccion = fechaRecoleccion;
        this.estado = estado;
    }
    
    //Método que forma parte del subsistema
    @Override
    public void ejecutar() throws SQLException {
        String sql = "EXEC InsertarDonacion ?, ?, ?, ?, ?";
        PreparedStatement statement = conexion.prepareStatement(sql);
        statement.setInt(1, excedenteID);
        statement.setInt(2, organizacionID);
        statement.setString(3, fechaAsignacion);
        statement.setString(4, fechaRecoleccion);
        statement.setString(5, estado);
        statement.executeUpdate();
    }
}