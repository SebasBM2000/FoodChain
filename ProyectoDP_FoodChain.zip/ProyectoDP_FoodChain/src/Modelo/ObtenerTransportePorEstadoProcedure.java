package Modelo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

//Esta clase cumple el rol de implementación concreta de IStoredProcedure para la tabla ObtenerTransportePorEstadoProcedure
//Este clase cumple el rol de un subsistema de la clase FacadeControlador
public class ObtenerTransportePorEstadoProcedure extends ConexionStoredProcedure implements IStoredProcedure {
    
    private String estado;

    public ObtenerTransportePorEstadoProcedure(String estado) {
        this.estado = estado;
    }

    //Método que forma parte del subsistema
    @Override
    public void ejecutar() throws SQLException {
        String sql = "EXEC ObtenerTransportePorEstado ?";
        PreparedStatement statement = conexion.prepareStatement(sql);
        statement.setString(1, estado);
        ResultSet resultSet = statement.executeQuery();

        // Procesar el resultado
        while (resultSet.next()) {
            System.out.println("RutaID: " + resultSet.getInt("RutaID"));
            System.out.println("DonacionID: " + resultSet.getInt("DonacionID"));
            System.out.println("Vehiculo: " + resultSet.getString("Vehiculo"));
            System.out.println("Conductor: " + resultSet.getString("Conductor"));
            System.out.println("FechaInicio: " + resultSet.getString("FechaInicio"));
            System.out.println("FechaFin: " + resultSet.getString("FechaFin"));
            System.out.println("Estado: " + resultSet.getString("Estado"));
            
        }
    }
}