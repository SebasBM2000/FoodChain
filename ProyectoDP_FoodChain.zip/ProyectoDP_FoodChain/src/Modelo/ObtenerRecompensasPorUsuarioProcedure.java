package Modelo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

//Esta clase cumple el rol de implementación concreta de IStoredProcedure para la tabla ObtenerRecompensasPorUsuarioProcedure
//Este clase cumple el rol de un subsistema de la clase FacadeControlador
public class ObtenerRecompensasPorUsuarioProcedure extends ConexionStoredProcedure implements IStoredProcedure {
    
    private int usuarioID;

    public ObtenerRecompensasPorUsuarioProcedure(int usuarioID) {
        this.usuarioID = usuarioID;
    }

    //Método que forma parte del subsistema
    @Override
    public void ejecutar() throws SQLException {
        String sql = "EXEC ObtenerRecompensasPorUsuario ?";
        PreparedStatement statement = conexion.prepareStatement(sql);
        statement.setInt(1, usuarioID);
        ResultSet resultSet = statement.executeQuery();

        // Procesar el resultado
        while (resultSet.next()) {
            System.out.println("RecompensaID: " + resultSet.getInt("RecompensaID"));
            System.out.println("DonacionID: " + resultSet.getInt("DonacionID"));
            System.out.println("UsuarioID: " + resultSet.getInt("UsuarioID"));
            System.out.println("Puntos: " + resultSet.getInt("Puntos"));
            System.out.println("FechaOtorgacion: " + resultSet.getString("FechaOtorgacion"));
            
        }
    }
}