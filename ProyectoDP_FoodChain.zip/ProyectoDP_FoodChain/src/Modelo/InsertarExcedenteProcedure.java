package Modelo;

import java.sql.PreparedStatement;
import java.sql.SQLException;

//Esta clase cumple el rol de implementación concreta de IStoredProcedure para la tabla InsertarExcedenteProcedure
//Este clase cumple el rol de un subsistema de la clase FacadeControlador
public class InsertarExcedenteProcedure extends ConexionStoredProcedure implements IStoredProcedure {

    private int usuarioID;
    private String descripcion;
    private double cantidad;
    private String unidadMedida;
    private String fechaCreacion;
    private String fechaCaducidad;
    private String estado;

    public InsertarExcedenteProcedure(int usuarioID, String descripcion, double cantidad, String unidadMedida, String fechaCreacion, String fechaCaducidad, String estado) {
        this.usuarioID = usuarioID;
        this.descripcion = descripcion;
        this.cantidad = cantidad;
        this.unidadMedida = unidadMedida;
        this.fechaCreacion = fechaCreacion;
        this.fechaCaducidad = fechaCaducidad;
        this.estado = estado;
    }

    //Método que forma parte del subsistema
    @Override
    public void ejecutar() throws SQLException {
        String sql = "EXEC InsertarExcedente ?, ?, ?, ?, ?, ?, ?";
        PreparedStatement statement = conexion.prepareStatement(sql);
        statement.setInt(1, usuarioID);
        statement.setString(2, descripcion);
        statement.setDouble(3, cantidad);
        statement.setString(4, unidadMedida);
        statement.setString(5, fechaCreacion);
        statement.setString(6, fechaCaducidad);
        statement.setString(7, estado);

        // Ejecuta el procedimiento almacenado
        statement.executeUpdate();
    }
}
