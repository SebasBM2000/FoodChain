package Modelo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

//Esta clase cumple el rol de implementación concreta de IStoredProcedure para la tabla ObtenerExcedentesPorEstadoProcedure
//Este clase cumple el rol de un subsistema de la clase FacadeControlador
public class ObtenerExcedentesPorEstadoProcedure extends ConexionStoredProcedure implements IStoredProcedure {

    private String estado;

    public ObtenerExcedentesPorEstadoProcedure(String estado) {
        this.estado = estado;
    }

    //Método que forma parte del subsistema
    @Override
    public void ejecutar() throws SQLException {
        String sql = "EXEC ObtenerExcedentesPorEstado ?";
        PreparedStatement statement = conexion.prepareStatement(sql);
        statement.setString(1, estado);

        ResultSet resultSet = statement.executeQuery();

        // Procesa el resultado de la consulta (puedes modificar esto según tus necesidades)
        while (resultSet.next()) {
            System.out.println("ExcedenteID: " + resultSet.getInt("ExcedenteID"));
            System.out.println("UsuarioID: " + resultSet.getInt("UsuarioID"));
            System.out.println("Descripcion: " + resultSet.getString("Descripcion"));
            System.out.println("Cantidad: " + resultSet.getDouble("Cantidad"));
            System.out.println("UnidadMedida: " + resultSet.getString("UnidadMedida"));
            System.out.println("FechaCreacion: " + resultSet.getString("FechaCreacion"));
            System.out.println("FechaCaducidad: " + resultSet.getString("FechaCaducidad"));
            System.out.println("Estado: " + resultSet.getString("Estado"));
            
        }
    }
}