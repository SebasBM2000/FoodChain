package Modelo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

//Esta clase cumple el rol de implementación concreta de IStoredProcedure para la tabla ObtenerRangosPorTipoDeRecompensaProcedure
//Este clase cumple el rol de un subsistema de la clase FacadeControlador
public class ObtenerRangosPorTipoDeRecompensaProcedure extends ConexionStoredProcedure implements IStoredProcedure {
    
    private String tipoRecompensa;

    public ObtenerRangosPorTipoDeRecompensaProcedure(String tipoRecompensa) {
        this.tipoRecompensa = tipoRecompensa;
    }

    //Método que forma parte del subsistema
    @Override
    public void ejecutar() throws SQLException {
        String sql = "EXEC ObtenerRangosPorTipoDeRecompensa ?";
        PreparedStatement statement = conexion.prepareStatement(sql);
        statement.setString(1, tipoRecompensa);
        ResultSet resultSet = statement.executeQuery();

        // Procesar el resultado
        while (resultSet.next()) {
            System.out.println("DetallesID: " + resultSet.getInt("DetallesID"));
            System.out.println("MinPuntos: " + resultSet.getInt("MinPuntos"));
            System.out.println("MaxPuntos: " + resultSet.getInt("MaxPuntos"));
            System.out.println("TipoRecompensa: " + resultSet.getString("TipoRecompensa"));
            System.out.println("Descripcion: " + resultSet.getString("Descripcion"));
            
        }
    }
}